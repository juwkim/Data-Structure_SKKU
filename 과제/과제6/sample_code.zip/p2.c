/*
 * SWE2015_42 Data Structures
 * 2020 Fall
 * Assignment 6 Sample Code
 * Youngjae Lee <yjlee4154@gmail.com>
 */
#include <stdio.h>
#include <stdlib.h>

struct bst_node {
    int key;
    int count;
    int count_left;
    int count_right;
    struct bst_node *parent, *left, *right;
};
typedef struct bst_node Node;


Node *BSTNodeNew(int key)
{
    Node *node = (Node *)malloc(sizeof(Node));
    node->key = key;
    node->count = 0;
    node->parent = NULL;
    node->left = NULL;
    node->right = NULL;
    return node;
}

Node *BSTNodeSearch(Node *root, int key)
{
    Node *node = root;

    while (node != NULL && node->key != key) {
        if(key < node->key)
            node = node->left;
        else
            node = node->right;
    }
    return node;
}

Node *BSTNodeMin(Node *root)
{
    Node *node = root;
    while (node->left != NULL)
        node = node->left;
    return node;
}

void BSTNodeInsert(Node **root, int key, int cnt)
{
    Node *node = *root;
    Node *nodep = NULL;

    while (node != NULL) {
        nodep = node;
        if (key == node->key) {
            node->count += cnt;
            return;
        } else if (key < node->key) {
            node->count_left += cnt;
            node = node->left;
        } else {
            node->count_right += cnt;
            node = node->right;
        }
    }

    Node *new_node = BSTNodeNew(key);
    new_node->count = cnt;
    new_node->parent = nodep;

    if (nodep == NULL)
        *root = new_node;
    else if (new_node->key < nodep->key)
        nodep->left = new_node;
    else
        nodep->right = new_node;
}

void BSTNodeTp(Node **root, Node *dest, Node *src)
{
    if (dest->parent == NULL) {
        *root = src;
    } else if (dest == dest->parent->left) {
        dest->parent->left = src;
        if (src != NULL)
            dest->parent->count_left = src->count + src->count_left + src->count_right;
        else
            dest->parent->count_left = 0;
    } else {
        dest->parent->right = src;
        if (src != NULL)
            dest->parent->count_right = src->count + src->count_left + src->count_right;
        else
            dest->parent->count_right = 0;
    }

    if(src != NULL)
        src->parent = dest->parent;

    if (dest->parent == NULL)
        return;

    Node *node = dest->parent;
    while (node->parent != NULL) {
        Node *par = node->parent;
        if (node == par->left) {
            par->count_left = node->count + node->count_left + node->count_right;
        } else {
            par->count_right = node->count + node->count_left + node->count_right;
        }
        node = node->parent;
    }
}

void BSTNodeDelete(Node **root, Node *target)
{
    Node *node;
    if (target->left == NULL) {
        node = target->right;
        BSTNodeTp(root, target, node);
    } else if (target->right == NULL) {
        node = target->left;
        BSTNodeTp(root, target, node);
    } else {
        node = BSTNodeMin(target->right);
        if (node != target->right) {
            BSTNodeTp(root, node, node->right);
            node->right = target->right;
            node->right->parent = node;
            node->count_right = node->right->count + node->right->count_left + node->right->count_right;
        }
        node->left = target->left;
        node->left->parent = node;
        node->count_left = node->left->count + node->left->count_left + node->left->count_right;
        BSTNodeTp(root, target, node);
    }
    free(target);
}

struct bst {
    Node *root;
};
typedef struct bst BST;

void BSTInit(BST *bst)
{
    bst->root = NULL;
}

void BSTInsert(BST *bst, int grade, int cnt)
{
    BSTNodeInsert(&bst->root, grade, cnt);
}

void BSTDelete(BST *bst, int grade, int cnt)
{
    Node *target = BSTNodeSearch(bst->root, grade);
    if (target == NULL)
        return;

    if (cnt > target->count)
        cnt = target->count;

    target = bst->root;
    while (target != NULL && target->key != grade) {
        if (grade < target->key) {
            target->count_left -= cnt;
            target = target->left;
        } else {
            target->count_right -= cnt;
            target = target->right;
        }
    }

    target->count -= cnt;
    if (target->count == 0)
        BSTNodeDelete(&bst->root, target);
}

int BSTSearch(BST *bst, int grade)
{
    Node *result = BSTNodeSearch(bst->root, grade);
    return result == NULL ? 0 : result->count;
}

int BSTRange(BST *bst, int left, int right)
{
    Node *node = bst->root;
    int cnt1 = 0;
    while (node != NULL) {
        if (node->key == left) {
            cnt1 += node->count_left;
            break;
        } else if (node->key < left) {
            cnt1 += node->count_left + node->count;
            node = node->right;
        } else {
            node = node->left;
        }
    }

    node = bst->root;
    int cnt2 = 0;
    while (node != NULL) {
        if (node->key == right) {
            cnt2 += node->count_left + node->count;
            break;
        } else if (node->key < right) {
            cnt2 += node->count_left + node->count;
            node = node->right;
        } else {
            node = node->left;
        }
    }
    return cnt2 - cnt1;
}

int BSTTop(BST *bst, int x)
{
    Node *node = bst->root;

    while (node != NULL) {
        if (node->count_left >= x) {
            node = node->left;
        } else if (node->count_left + node->count >= x) {
            break;
        } else {
            x -= node->count_left + node->count;
            node = node->right;
        }
    }
    return node == NULL ? -1 : node->key;
}

int main(void)
{
    int n;
    int sr;

    sr = scanf("%d", &n);

    Node *root_node = NULL;
    BST bst;
    BSTInit(&bst);
    int cnt_total = 0;

    for (int i = 0; i < n; i++) {
        char op;
        int x, y;
        sr = scanf(" %c", &op);
        switch (op) {
        case 'I':
            sr = scanf("%d %d", &x, &y);
            BSTInsert(&bst, x, y);
            cnt_total += y;
            break;
        case 'D':
            sr = scanf("%d %d", &x, &y);
            BSTDelete(&bst, x, y);
            cnt_total -= y;
            break;
        case 'C':
            sr = scanf("%d", &x);
            printf("%d\n", BSTSearch(&bst, x));
            break;
        case 'R':
            sr = scanf("%d %d", &x, &y);
            printf("%d\n", BSTRange(&bst, x, y));
            break;
        case 'T':
            sr = scanf("%d", &x);
            printf("%d\n", BSTTop(&bst, x));
            break;
        default:
            printf("????\n");
            return 1;
        }
    }
    return 0;
}
