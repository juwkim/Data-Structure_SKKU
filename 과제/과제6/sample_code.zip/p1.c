/*
 * SWE2015_42 Data Structures
 * 2020 Fall
 * Assignment 6 Sample Code
 * Youngjae Lee <yjlee4154@gmail.com>
 */
#include <stdio.h>

typedef struct Lamp {
    int left;
    int right;
    int num;
} Lamp;

void Swap(Lamp *list, int x, int y)
{
    Lamp tmp = list[x];
    list[x] = list[y];
    list[y] = tmp;
}

int Partition(Lamp *list, int left, int right)
{
    Lamp pivot = list[left];
    int low = left + 1, high = right;
    while (1) {
        while (low < right &&
               (list[low].left < pivot.left ||
                (list[low].left == pivot.left && list[low].right > pivot.right)))
            low++;
        while (high > left &&
               (list[high].left > pivot.left ||
                (list[high].left == pivot.left && list[high].right < pivot.right)))
            high--;

        if (low < high)
            Swap(list, low, high);
        else
            break;
    }
    Swap(list, left, high);
    return high;
}

void Quicksort(Lamp *list, int left, int right)
{
    if (left < right) {
        int mid = Partition(list, left, right);
        Quicksort(list, left, mid - 1);
        Quicksort(list, mid + 1, right);
    }
}

Lamp lamp_list[500000];
int unremoved[500000];
int unremoved_cnt = 0;

int main(void)
{
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        int x, b;
        scanf("%d %d", &x, &b);
        lamp_list[i].left = x - b;
        lamp_list[i].right = x + b;
        lamp_list[i].num = i + 1;
    }

    Quicksort(lamp_list, 0, n-1);

    int right_end = -100000000;
    for (int i = 0; i < n; i++) {
        if (right_end < lamp_list[i].right) {
            unremoved[unremoved_cnt] = i;
            unremoved_cnt++;
            right_end = lamp_list[i].right;
        }
    }

    printf("%d\n", unremoved_cnt);
    for (int i = 0; i < unremoved_cnt; i++)
        printf("%d ", lamp_list[unremoved[i]].num);
    printf("\n");

    return 0;
}
