#include <stdio.h>
#include <stdlib.h>

typedef struct _Tree {
	int item;
	struct _Tree* left;
	struct _Tree* right;
} Tree;

int k = 1;

Tree* create(int item);
void link(Tree* root, int* pre, int* in, int lEnd, int rEnd);
int inorder(int item, int* in, int lEnd, int rEnd);
void postorder(Tree* root);

int main()
{
	int n; scanf("%d", &n);
	int pre[n], in[n];
	for (int i = 0; i < n; ++i)
		scanf("%d", &pre[i]);
	for (int i = 0; i < n; ++i)
		scanf("%d", &in[i]);
	
	Tree* root = create(pre[0]);
	link(root, pre, in, 0, n - 1);
	postorder(root);
	
	return 0;
}

Tree* create(int item)
{
	Tree* node = malloc(sizeof(Tree));
	node->item = item;
	node->left = NULL;
	node->right = NULL;
	
	return node;
}

void link(Tree* root, int* pre, int* in, int lEnd, int rEnd)
{
	if (lEnd > rEnd) return;
	int check = inorder(root->item, in, lEnd, rEnd);
	
	if (lEnd < check) { //left가 있을 때
		Tree* _left = create(pre[k++]);
		root->left = _left;
		link(_left, pre, in, lEnd, check - 1);
	}
	
	if (check < rEnd) { //right가 있을 때
		Tree* _right = create(pre[k++]);
		root->right = _right;
		link(_right, pre, in, check + 1, rEnd);
	}
}

int inorder(int item, int* in, int lEnd, int rEnd)
{
	for (int i = lEnd; i < rEnd; ++i) {
		if (item == in[i]) return i;
	}
}

void postorder(Tree* root)
{
	if (root != NULL)
	{
		postorder(root->left);
		postorder(root->right);
		printf("%d ", root->item);
	}
}
