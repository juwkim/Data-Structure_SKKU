#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct _Tree {
	int item;
	struct _Tree* left;
	struct _Tree* right;
} Tree;

int key;

Tree* create(int item);
void link(Tree* root, int n);
void inorder(Tree* node);

int main()
{
	int n; scanf("%d %d", &key, &n);

	Tree* root = create(0);
	link(root, n);
	inorder(root);
	
	return 0;
}

Tree* create(int item)
{
	Tree* node = malloc(sizeof(Tree));
	node->item = item;
	node->left = NULL;
	node->right = NULL;
	
	return node;
}

void link(Tree* root, int n)
{
	if (n == 1) return;
	
	Tree* _left = create(0);
	Tree* _right = create(1);
	
	root->left = _left;
	root->right = _right;
	
	link(_left, n - 1);
	link(_right, n - 1);
}

void inorder(Tree* root)
{
	if (root != NULL)
	{
		inorder(root->left);
		printf("%c", (root->item == key)? 'V' : '^');
		inorder(root->right);
	}
}