#include <stdio.h>
typedef struct _Node{
	int id;
	struct _Node* next;
}Node;
typedef struct{
	int num,contacts,range;
	int* checked,*patients;
	Node** heads;
}Graph;
typedef struct{
	Node* front;
	Node* rear;
}Queue;
void initGraph(Graph* graph,int num){
	graph->num=num;
	graph->contacts=0;
	graph->checked=(int*)malloc(sizeof(int)*num);
	graph->patients=(int*)malloc(sizeof(int)*num);
	graph->heads=(Node**)malloc(sizeof(Node*)*num);
	for(int i=0;i<num;i++){
		graph->checked[i]=0;
		graph->patients[i]=0;
		graph->heads[i]=(Node*)malloc(sizeof(Node));
		graph->heads[i]->id=i;
	}
}
void addEdge(Graph* graph,int src,int dest){
	if(src==dest) return;
	Node* node1,*node2,*cur;
	cur=graph->heads[src];
	while(1){
		if(cur->next==NULL){
			node1=(Node*)malloc(sizeof(Node));
			node1->id=dest;
			node1->next=NULL;
			cur->next=node1;
			break;
		}
		cur=cur->next;
		if(cur->id==dest) break;
	}
	cur=graph->heads[dest];
	while(1){
		if(cur->next==NULL){
			node2=(Node*)malloc(sizeof(Node));
			node2->id=src;
			node2->next=NULL;
			cur->next=node2;
			break;
		}
		cur=cur->next;
		if(cur->id==src) break;
	}
}
void initQueue(Queue* queue){
	queue->front=queue->rear=NULL;
}
int isEmpty(Queue* queue){
	return queue->front==NULL;
}
void enQueue(Queue* queue,int id){
	Node* node=(Node*)malloc(sizeof(Node));
	node->id=id;
	node->next=NULL;
	if(isEmpty(queue)) queue->front=queue->rear=node;
	else{
		queue->rear->next=node;
		queue->rear=node;
	}
}
int deQueue(Queue* queue){
	Node* temp=queue->front;
	int ret=temp->id;
	if(temp->next==NULL)queue->front=queue->rear=NULL;
	else queue->front=temp->next;
	free(temp);
	return ret;
}
void BFS(Graph* graph,int start){
	Queue queue;
	initQueue(&queue);
	int* visited=(int*)malloc(sizeof(int)*graph->num);
	for(int i=0,len=graph->num;i<len;i++)visited[i]=0;
	enQueue(&queue,start);
	int i=0,j=1,k=0;
	while(!isEmpty(&queue)&&k<=graph->range){
		int vertex=deQueue(&queue);
		j--;
		if(visited[vertex])	continue;
		else{
			visited[vertex]=1;
			if(!graph->patients[vertex]&&!graph->checked[vertex])	graph->contacts++;
			graph->checked[vertex]=1;
		}
		Node* cur=graph->heads[vertex]->next;
		if(k<graph->range){
			while(cur!=NULL){
				if(!visited[cur->id]){
					i++;
					enQueue(&queue,cur->id);
				}
				cur=cur->next;
			}
		}
		if(j<=0){
			j=i;
			i=0;
			k++;
		}
	}
}
int main() {
	int n,x,y;
	Graph graph;
	scanf("%d %d %d %d",&n,&graph.range,&x,&y);
	initGraph(&graph,n);
	for(int i=0;i<x;i++){
		int temp;
		scanf("%d",&temp);
		graph.patients[temp]=1;
	}
	for(int i=0;i<y;i++){
		int a,b;
		scanf("%d %d",&a,&b);
		addEdge(&graph,a,b);
	}
	for(int i=0;i<n;i++){
		if(graph.patients[i])BFS(&graph,i);
	}
	printf("%d",graph.contacts);
	return 0;
}
