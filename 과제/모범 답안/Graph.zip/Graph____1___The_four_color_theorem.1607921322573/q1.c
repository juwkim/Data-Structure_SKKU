#include <stdio.h>
typedef struct _Node{
	int id;
	struct _Node* next;
}Node;
typedef struct{
	int num,countries;
	int* checked,*colors;
	Node** heads;
}Graph;
typedef struct{
	Node* top;
}Stack;
void initGraph(Graph* graph,int num){
	graph->countries=0;
	graph->num=num;
	graph->checked=(int*)malloc(sizeof(int)*num);
	graph->colors=(int*)malloc(sizeof(int)*num);
	graph->heads=(Node**)malloc(sizeof(Node*)*num);
	for(int i=0;i<num;i++){
		graph->heads[i]=(Node*)malloc(sizeof(Node));
		graph->heads[i]->next=NULL;
		graph->checked[i]=0;
	}
}
void addEdge(Graph* graph,int src,int dest){
	if(src==dest) return;
	Node* node1,*node2,*cur;
	cur=graph->heads[src];
	while(1){
		if(cur->next==NULL){
			node1=(Node*)malloc(sizeof(Node));
			node1->id=dest;
			node1->next=NULL;
			cur->next=node1;
			break;
		}
		cur=cur->next;
		if(cur->id==dest) break;
	}
	cur=graph->heads[dest];
	while(1){
		if(cur->next==NULL){
			node2=(Node*)malloc(sizeof(Node));
			node2->id=src;
			node2->next=NULL;
			cur->next=node2;
			break;
		}
		cur=cur->next;
		if(cur->id==src) break;
	}
}
void initStack(Stack* stack){
	stack->top=NULL;
}
void push(Stack* stack,int id){
	Node* node=(Node*)malloc(sizeof(Node));
	node->id=id;
	node->next=stack->top;
	stack->top=node;
}
int isEmpty(Stack* stack){
	return stack->top==NULL;
}
int pop(Stack* stack){
	Node* temp=stack->top;
	int ret=temp->id;
	stack->top=temp->next;
	free(temp);
	return ret;
}
void DFS(Graph* graph,int start){
	Stack stack;
	int* visited=(int*)malloc(sizeof(int)*graph->num);
	int color=graph->colors[start];
	for(int i=0,len=graph->num;i<len;i++) visited[i]=0;
	initStack(&stack);
	push(&stack,start);
	while(!isEmpty(&stack)){
		Node* cur;
		int vertex=pop(&stack);
		if(visited[vertex])continue;
		else{
			visited[vertex]=1;
			if(color==graph->colors[vertex])graph->checked[vertex]=1;
		}
		cur=graph->heads[vertex]->next;
		while(cur!=NULL){
			if(!visited[cur->id]&&color==graph->colors[cur->id]) push(&stack,cur->id);
			cur=cur->next;
		}
	}
}
int main() {
	int n,m;
	Graph graph;
	scanf("%d %d",&n,&m);
	initGraph(&graph,n);
	for(int i=0;i<n;i++){
		int color;
		scanf("%d",&color);
		graph.heads[i]->id=i;
		graph.colors[i]=color;
	}
	for(int i=0;i<m;i++){
		int a,b;
		scanf("%d %d",&a,&b);
		addEdge(&graph,a,b);
	}
	for(int i=0;i<n;i++){
		if(!graph.checked[i]){
			DFS(&graph,i);
			graph.countries++;
		}
	}
	printf("%d",graph.countries);
	return 0;
}
